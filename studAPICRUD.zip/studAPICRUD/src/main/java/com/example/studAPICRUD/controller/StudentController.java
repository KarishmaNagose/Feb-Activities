package com.example.studAPICRUD.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.studAPICRUD.model.Student;
import com.example.studAPICRUD.service.StudentService;

@RestController
@RequestMapping ("/api")
public class StudentController {
	private static final Logger log = LoggerFactory.getLogger(StudentController.class);
	@Autowired
	private StudentService studentService;
	
	
	@GetMapping ("/students")
	public List<Student>getAllStudents(){ 
		return studentService.getAllStudents();
		
	}
	@GetMapping("/student/{studId}")
	public ResponseEntity<Student>getStudentById(@PathVariable Integer studId ){
		try {
			
			Student student =studentService.getStudentById(studId);
			log.info("student {} details found" , studId);
			return new ResponseEntity<Student>(student , HttpStatus.OK);
		}catch(Exception e){
			
			log.info("student {} details Not found" , studId);
			return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
		}
	
	}
	
//	@GetMapping("/students/{stdYear}")
//	public ResponseEntity<Student>getStudentByYear(@PathVariable Integer stdYear ){
//		try {
//			
//			Student student =studentService.getStudentByYear(stdYear);
//			log.info("Students Of the year {} " , stdYear);
//			return new ResponseEntity<Student>(student , HttpStatus.OK);
//		}catch(Exception e){
//			
//			log.info("student of the year {} Not found" , stdYear);
//			return new ResponseEntity<Student>(HttpStatus.NOT_FOUND);
//		}
//	
//	}
	
	@GetMapping ("/students/{stdYear}")
	public List<Student>getAllStudentsByYear(@PathVariable Integer stdYear){ 
		return studentService.getStudentByYear(stdYear);
	}
	
	
     
	
	@PostMapping("/students")
	public String addStudent(@RequestBody Student student) {
		
     studentService.createStudent(student);
	return "Record created Succesfully";

}
	@PutMapping("/students/{id}")
	public ResponseEntity<?> updateStudentData(@RequestBody Student student, @PathVariable Integer id){
		try {
			Student stud=studentService.getStudentById(id);
//			stud.setStdid(student.getStdid());
			stud.setName(student.getName());
			stud.setCity_name(student.getCity_name());
			stud.setEmail(student.getEmail());
			stud.setYear(student.getYear());
			Student student1=studentService.createStudent(stud);
			log.info("student {} details updated Succesfully" , id);
			return new ResponseEntity<>(student1,HttpStatus.OK);
			
		}
	catch(Exception e) {
		log.info("student {} details Update Failed" , id);
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	}
	

	@DeleteMapping("/students/{id}")
	public void deleteStudent(@PathVariable Integer id) {
		studentService.deleteStudent(id);
		
	}
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	