package com.example.studAPICRUD.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.studAPICRUD.model.Student;

@Repository

public interface StudentRepository extends JpaRepository<Student, Integer> {
     
//    @Query(value="Select * from Student where year=year", nativeQuery=true)
//	Student findByYear(Integer stdYear);
	
	@Query(value="select * from Student where year = ?1", nativeQuery=true)
	List<Student> findByYear( Integer year);
	
	
}

