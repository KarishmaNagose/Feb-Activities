package com.example.studAPICRUD.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.studAPICRUD.model.Student;
import com.example.studAPICRUD.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
	private StudentRepository repo;
	
	//used for retrieving or fetching data from database
	public List<Student> getAllStudents() {
		return repo.findAll();
	}
	
	//data fetching by id 
	public Student getStudentById(Integer studentId) {
        return repo.findById(studentId).get();
        
    }
	//create new student record
	public Student createStudent(Student student) {
		return repo.save(student);
		
	}
	
//	public Student updateStudent(Student student) {
//		return repo.save(student);
//		
//	}
	
	public void deleteStudent(Integer studentId) {
		repo.deleteById(studentId);
		
	}


	public List<Student>getStudentByYear(Integer stdYear){
		return repo.findByYear(stdYear);
		
	}
	

}
