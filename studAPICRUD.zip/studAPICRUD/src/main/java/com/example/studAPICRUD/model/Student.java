package com.example.studAPICRUD.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="STUDENT")
public class Student {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="STDID")
	private Integer stdid;
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="CITY_NAME")
	private String cityName;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="YEAR")
	private Integer year;
	public Student() {
		super();
		
	}
	public Student(Integer stdid, String name, String city_name, String email, Integer year) {
		super();
		this.stdid = stdid;
		this.name = name;
		this.cityName = city_name;
		this.email = email;
		this.year = year;
	}
	public Integer getStdid() {
		return stdid;
	}
	public void setStdid(Integer stdid) {
		this.stdid = stdid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity_name() {
		return cityName;
	}
	public void setCity_name(String city_name) {
		this.cityName = city_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "Student [stdid=" + stdid + ", name=" + name + ", city_name=" + cityName + ", email=" + email
				+ ", year=" + year + "]";
	}
	

}
