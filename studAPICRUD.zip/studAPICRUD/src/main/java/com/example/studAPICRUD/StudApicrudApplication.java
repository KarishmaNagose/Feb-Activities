package com.example.studAPICRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudApicrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudApicrudApplication.class, args);
	}

}
